
//==  VARS  ==================================================================//

var grid,gridWidth,gridHeight;
var puzzleLs = [];
var doorLs   = [];
var cellSize = 9;
var padding  = 0;

var accessCtr = 0;
var playerX = 3;
var playerY = 3;

var mouseX = 0;
var mouseY = 0;

//==  ACCESS-RELATED  ========================================================//

function updateAccessableToPlayer(doorDepth){
	doorDepth = doorDepth || Infinity;
	++accessCtr;
	function recurse(x,y,doorCtr){
		if(!grid[x][y].isTraversable)return;
		if(grid[x][y].lastAccess == accessCtr)return;
		var d = doorCtr+(grid[x][y].type=='d'?1:0);
		grid[x][y].lastAccess = accessCtr;
		grid[x][y].doorsAway = d;
		if(d >= doorDepth)return;
		recurse(x,y-1,d);recurse(x,y+1,d);
		recurse(x-1,y,d);recurse(x+1,y,d);
	}recurse(playerX,playerY,0);
}

//==  CONNECT PUZZLES TO DOORS AND DETERMINE START STATE  ====================//

function generateConnections(){
	// cleanup any previous attempts
	for(var p in puzzleLs)puzzleLs[p].doorLs = [];
	for(var d in doorLs){
		doorLs[d].isTraversable = true;
		doorLs[d].puzzleLs = [];
	}

	// randomly assign connections and initial states
	for(var p in puzzleLs){
		playerX = puzzleLs[p].x;
		playerY = puzzleLs[p].y;
		updateAccessableToPlayer(2);
		for(var d in doorLs)if(doorLs[d].lastAccess == accessCtr && !rInt(2)){
			puzzleLs[p].doorLs.push(doorLs[d]);
			doorLs[d].puzzleLs.push(puzzleLs[p]);
		}if(rInt(2))puzzleLs[p].onAction();
	}for(var d in doorLs)if(rInt(2))doorLs[d].toggle();
}

function createPath(){
	// have player traverse from exit to initial position
	playerX = 17;
	playerY = 33;

	// newPuzzles
	// unvisitedPuzzles
	updateAccessableToPlayer();
}

//==  INITIALIZATION  ========================================================//

function init(){
	var map = m1;
	gridHeight = map.length;
	gridWidth = map[0].length;

	grid = [];
	for(var i=0;i<gridWidth;++i){
		grid[i] = [];
		for(var j=0;j<gridHeight;++j)grid[i][j] = new tile(i,j,map[j][i]);
	}

	generateConnections();
	createPath();

	canvas.width  = gridWidth*(cellSize+padding)-padding;
	canvas.height = gridHeight*(cellSize+padding)-padding;
}

//==  RENDER CURRENT STATE  ==================================================//

function render(){
	rgb(0,0,0);
	rect(0,0,canvas.width,canvas.height);

	var cs = cellSize;
	var csp = cs+padding;
	for(var i=0;i<gridWidth;++i)for(var j=0;j<gridHeight;++j){
		grid[i][j].setColor();
		rect(i*csp,j*csp,i*csp+cs,j*csp+cs);
	}

	function tileToList(x,y,ls){
		for(var i in ls){
			line(x*csp+cs/2,y*csp+cs/2,ls[i].x*csp+cs/2,ls[i].y*csp+cs/2);
			circle(ls[i].x*csp+cs/2,ls[i].y*csp+cs/2,cs/3);
		}
	}

	gfx.lineWidth = 3;
	rgba(0,0,1,0.5);
	if(grid[playerX][playerY].type == 'p')tileToList(playerX,playerY,grid[playerX][playerY].doorLs);
	if(grid[playerX][playerY].type == 'd')tileToList(playerX,playerY,grid[playerX][playerY].puzzleLs);
	rgba(1,1,0,0.5);
	if(grid[mouseX][mouseY].type == 'p')tileToList(mouseX,mouseY,grid[mouseX][mouseY].doorLs);
	if(grid[mouseX][mouseY].type == 'd')tileToList(mouseX,mouseY,grid[mouseX][mouseY].puzzleLs);

	rgb(1,1,1);
	circle(playerX*csp+cs/2,playerY*csp+cs/2,cs*0.7);
}

//==  CONTROLS  ==============================================================//

canvas.addEventListener("mouseup",function(e){
	var rect = canvas.getBoundingClientRect();
	mouseX = Math.floor((e.clientX-rect.left)/(cellSize+padding));
	mouseY = Math.floor((e.clientY-rect.top)/(cellSize+padding));
	render();
});

document.addEventListener("keyup",function(e){
	function movePlayerTo(dx,dy){
		if(!grid[playerX+dx][playerY+dy].isTraversable)return;
		grid[playerX][playerY].onExit();
		grid[playerX+dx][playerY+dy].onEnter();
		playerX += dx;
		playerY += dy;
	};

	switch(e.keyCode){
		case 87 /*     w */ : movePlayerTo( 0,-1);break;
		case 83 /*     s */ : movePlayerTo( 0,+1);break;
		case 65 /*     a */ : movePlayerTo(-1, 0);break;
		case 68 /*     d */ : movePlayerTo(+1, 0);break;
		case 32 /* space */ : grid[playerX][playerY].onAction();break;
	}render();
});
