var tile = function(x,y,typeChar){

	this.x             = x;
	this.y             = y;
	this.type          = typeChar;
	this.isTraversable = false;

	this.lastAccess = 0;
	this.doorsAway  = 0; // valid when lastAccess == accessCtr

	this.onEnter  = function(){/* by default do nothing */};
	this.onAction = function(){/* by default do nothing */};
	this.onExit   = function(){/* by default do nothing */};
	this.setColor = function(){rgb(0,0,0);};

	switch(typeChar){

	case 'f': // --------------------------------------------- FLOOR

		this.isTraversable = true;
		this.setColor = function(){
			if(this.lastAccess == accessCtr)rgb(0.5,0.5,0.5);
			else rgb(0.1,0.1,0.1);
		};
		break;

	case 'x': // ---------------------------------------------- EXIT

		this.isTraversable = true;
		this.onEnter = function(){console.log("YOU WIN");};
		this.setColor = function(){
			if(this.lastAccess == accessCtr)rgb(0.5,0.5,0.5);
			else rgb(0.1,0.1,0.1);
		};
		break;

	case 'w': // ---------------------------------------------- WALL

		this.setColor = function(){rgb(0.3,0.3,0.3);};
		break;

	case 'p': // -------------------------------------------- PUZZLE

		puzzleLs.push(this);
		this.isTraversable = true;
		this.toggleState = false;
		this.doorLs = [];
		this.onAction = function(){
			this.toggleState=!this.toggleState;
			for(var d in this.doorLs)this.doorLs[d].toggle();
			updateAccessableToPlayer();
		};
		this.setColor = function(){
			if(this.toggleState)rgb(0,1,0);
			else rgb(1,0,0);
		};
		break;

	case 'd': // ---------------------------------------------- DOOR

		doorLs.push(this);
		this.puzzleLs = [];
		this.isTraversable = true;
		this.toggle = function(){this.isTraversable=!this.isTraversable;}
		this.setColor = function(){
			if(this.isTraversable)rgb(0.5,0.5,0.5);
			else rgb(0.1,0.1,0.1);
		};
		break;

	}
}
